#include <iostream>
#include "Book.h"

int main() {
Book w;
std::cout << w;
return 0;
}