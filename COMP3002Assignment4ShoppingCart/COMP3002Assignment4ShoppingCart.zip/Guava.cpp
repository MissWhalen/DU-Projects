//
// Created by Briana on 3/4/2021.
//

#include "Guava.h"

double Guava::getPrice() const {
    return 6;
}

std::string Guava::getName() const {
    return "Guava";
}
