//
// Created by Briana on 2/22/2021.
//

#include "DragonFruit.h"

double DragonFruit::getPrice() const {
    return 7;
}

std::string DragonFruit::getName() const {
    return "DragonFruit";
}
