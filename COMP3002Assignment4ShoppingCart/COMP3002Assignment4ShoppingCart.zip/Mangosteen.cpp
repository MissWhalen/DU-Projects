//
// Created by Briana on 3/4/2021.
//

#include "Mangosteen.h"

double Mangosteen::getPrice() const {
    return 8;
}

std::string Mangosteen::getName() const {
    return "Mangosteen";
}
