//
// Created by Briana on 3/20/2021.
//

#ifndef COMP3002FINALQUESTION3_NODE_H
#define COMP3002FINALQUESTION3_NODE_H
#include "Minststack.h"


class Node  {
//int value;
//node * min;
//I don't know what I'm doing here


};


#endif //COMP3002FINALQUESTION3_NODE_H
