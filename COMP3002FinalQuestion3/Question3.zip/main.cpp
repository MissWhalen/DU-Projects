#include <iostream>
#include <vector>
#include "Minststack.h"
#include"Node.h"

void test_Minstack();



int main() {
Minststack b;
b.push(2);
b.push(5);
b.push(6);
b.push(8);


    return 0;
}


void test_Minstack() {
//test variables
//expected result
//actual result
//print out error message

}