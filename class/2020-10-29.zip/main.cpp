#include <iostream>
#include <random>
#include <string>
#include <fstream>

void print_random_numbers();


std::string read_file(std::string filename);

void write_file(std::string filename, std::string message);

void other_reading_file_things(std::string filename);

int main() {
    print_random_numbers();
/*
    try {
        write_file("testoutput.txt", "Test output");
    } catch (std::runtime_error e) {
        std::cout << "error writing to file: " << e.what() << "\n";
    }

    try {
        std::string result = read_file("Pride_and_Prejudice.txt");
        std::cout << result << "\n";
    } catch (std::runtime_error e) {
        std::cout << "Error reading file: " << e.what() << "\n";
    }
     */

    //other_reading_file_things("Pride_and_Prejudice.txt");
    return 0;
}

void other_reading_file_things(std::string filename) {
    std::ifstream in(filename);

    if (!in.is_open()) {
        throw std::runtime_error("Could not open file for reading");
    }

    for (int i = 0; i < 10; ++i) {
        std::string foo;
        in >> foo;
        std::cout << "foo = '" << foo << "'\n";
    }

    in.close();
}


std::string read_file(std::string filename) {
    std::ifstream in(filename);

    if (!in.is_open()) {
        throw std::runtime_error("Could not open file for reading");
    }

    std::string result;

    // Slow but reliable way of reading a complete file, character by character
    // eof - end of file
    while (!in.eof()) {
        char c = in.get();

        if (in.gcount() != 1) {
            // Hit EOF
            break;
        }

        result += c;
    }
    in.close();

    return result;
}

void write_file(std::string filename, std::string message) {
    std::ofstream out(filename);

    if (!out.is_open()) {
        throw std::runtime_error("Could not open file for writing");
    }

    out << message;

    out.close();
}


void print_random_numbers() {
    // Pseudo-Random numbers PRNG

    // Random device is the source of initial randomness
    std::random_device rd;

    // Declare PRNG
    // Declares a Mersenne Twister PRNG with setup 19937
    // Seed it with the random device
    std::mt19937 prng(rd());

    // Declare distribution
    std::uniform_int_distribution<> distribution(1, 6);

    std::cout << "Random numbers: ";
    for (int i = 0; i < 10; ++i) {
        std::cout << distribution(prng) << " ";
    }
    std::cout << "\n";
}
